# PulseForge

A clean-room Android acid groovebox. It uses original branding, a custom interface, and real-time synthesized audio. It contains no proprietary code, samples, names, or interface assets.

## Interactive hardware rack build 0.4
- Two monophonic acid-inspired synth engines behind an A/B toggle, each with 16 steps
- Distinct original "8" and "9" drum sections, each synthesizing kick, snare, hat, and clap with different envelopes and tone
- Touch-drag control of all synth knobs, mixer pan/send knobs, and channel faders, wired directly to real-time audio parameters
- Per-step low/high velocity plus accent editing with separate red, amber, and violet state cues
- Play/stop, clear, and local pattern snapshot
- Dense portrait hardware rack interface with silver panels, red numeric displays, mixer strips, and eight pattern banks
- Portrait phone interface, Android 8+

## Deliberately open product decisions
The first build does **not** lock in a song format, automation model, export format, MIDI behavior, pattern-chain limits, or exact voice architecture. Those need product decisions before implementation. A sensible next milestone is: multiple named patterns + chain view, per-step accent/slide/note editing, live automation recording, mixer/mutes, and WAV export. MIDI clock and Ableton Link should be evaluated separately because they shape timing architecture.

## Build
Set `sdk.dir` in `local.properties`, then run `./gradlew test assembleDebug`. Install `app/build/outputs/apk/debug/app-debug.apk`.

## Acid accent model

Accent is modeled separately from low/high step velocity. An accented step uses a short filter-envelope decay independent of the DECAY knob, adds a softened envelope-shaped amplitude lift, and charges a retained filter-sweep state. Closely repeated accents build that state higher; its audible contribution grows with resonance. This is an original clean-room approximation based on public descriptions of the instrument behavior, not copied circuitry or code. Physical-device listening remains necessary to tune the final constants.

## 0.6 timing controls
Each acid engine has an independent ADV page with Slide Time and Accent Decay. Slide Time maps the glide to approximately 20-500 ms and Accent Decay maps the separate accent filter/amplitude envelope to approximately 35-300 ms. These values persist per engine without occupying the main six-knob performance panel.

## 0.6.1 fixes and mixer Mute/Solo
- Fixed a tap-routing fault that dropped every touch on Acid Engine B: STEP EDIT pitch/octave/accent/slide keys, the step strip, SAW/SQUARE and ADSR toggles, and the ADV page now respond on both engines.
- ADV Slide Time and Accent Decay knobs show live millisecond readouts while dragging; values persist per engine and reach the audio engine in real time.
- Each mixer channel (ACID A, ACID B, DRUM 8, DRUM 9) now has M (mute) and S (solo) buttons. Mute always silences its channel. When one or more solos are active, only soloed channels play, and a muted solo channel stays silent. Mute/solo are session state and are not persisted.
